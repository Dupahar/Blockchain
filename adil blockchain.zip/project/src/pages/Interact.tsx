import React, { useState } from 'react';
import { Send, RefreshCw } from 'lucide-react';
import { sendTransaction } from '../lib/avalanche';

const Interact = () => {
  const [method, setMethod] = useState('');
  const [params, setParams] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [vmID, setVmID] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (!vmID) {
        throw new Error('VM ID is required');
      }

      let parsedParams;
      try {
        parsedParams = JSON.parse(params);
      } catch {
        throw new Error('Invalid JSON parameters');
      }

      const result = await sendTransaction(vmID, method, parsedParams);
      setResponse(JSON.stringify(result, null, 2));
    } catch (error) {
      setResponse(JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Failed to process transaction'
      }, null, 2));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-gray-800 rounded-lg p-6">
        <h2 className="text-2xl font-bold mb-4">Interact with VM</h2>
        <p className="text-gray-300 mb-6">
          Send commands and interact with your deployed Virtual Machine.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">
              VM ID
            </label>
            <input
              type="text"
              value={vmID}
              onChange={(e) => setVmID(e.target.value)}
              className="w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              placeholder="Enter VM ID"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Method
            </label>
            <input
              type="text"
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className="w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              placeholder="Enter method name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Parameters (JSON)
            </label>
            <textarea
              value={params}
              onChange={(e) => setParams(e.target.value)}
              className="w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 h-32"
              placeholder='{"key": "value"}'
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-lg flex items-center justify-center ${
              loading ? 'bg-gray-600 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {loading ? (
              <>
                <RefreshCw className="animate-spin mr-2" />
                Processing...
              </>
            ) : (
              <>
                <Send className="mr-2" />
                Send Transaction
              </>
            )}
          </button>
        </form>

        {response && (
          <div className="mt-6">
            <h3 className="text-xl font-semibold mb-2">Response</h3>
            <pre className="bg-gray-900 p-4 rounded-lg overflow-x-auto">
              {response}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default Interact;