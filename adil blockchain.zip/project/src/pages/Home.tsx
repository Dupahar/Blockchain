import React from 'react';
import { ArrowRight, Box, Zap, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">
          Custom Virtual Machine for Avalanche Network
        </h2>
        <p className="text-gray-300 text-lg">
          Built with HyperSDK for the East India Blockchain Summit 2025
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <FeatureCard
          icon={<Box className="w-8 h-8 text-blue-400" />}
          title="Custom VM"
          description="Specialized virtual machine built using HyperSDK with optimized performance"
        />
        <FeatureCard
          icon={<Zap className="w-8 h-8 text-yellow-400" />}
          title="High Performance"
          description="Capable of handling 100k TPS with advanced optimizations"
        />
        <FeatureCard
          icon={<Shield className="w-8 h-8 text-green-400" />}
          title="Secure Design"
          description="Built with security-first approach and best practices"
        />
      </div>

      <div className="text-center">
        <Link
          to="/deploy"
          className="inline-flex items-center px-6 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Get Started
          <ArrowRight className="ml-2 w-5 h-5" />
        </Link>
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) => {
  return (
    <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
};

export default Home;