import React, { useState, useEffect } from 'react';
import { Upload, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { deployVM, getVMStatus, VMConfig } from '../lib/avalanche';

const Deploy = () => {
  const [deployStatus, setDeployStatus] = useState<'idle' | 'deploying' | 'success' | 'error'>('idle');
  const [logs, setLogs] = useState<Array<{ message: string; timestamp: string }>>([]);
  const [vmConfig, setVmConfig] = useState<VMConfig>({
    name: 'HyperSDK-Custom-VM',
    vmID: `vm-${Date.now().toString(36)}`,
    fxIDs: ['secp256k1fx'],
    genesisData: JSON.stringify({
      initialState: {},
      timestamp: Date.now() * 1000000,
      networkID: 12345,
      allocation: []
    }, null, 2)
  });

  const addLog = (message: string) => {
    setLogs(prev => [...prev, {
      message,
      timestamp: new Date().toISOString()
    }]);
  };

  const handleDeploy = async () => {
    setDeployStatus('deploying');
    setLogs([]);

    try {
      addLog('Initializing deployment to Avalanche Fuji Testnet...');
      
      addLog('Creating subnet...');
      const result = await deployVM(vmConfig);
      
      addLog(`Subnet created with ID: ${result.subnetID}`);
      addLog(`Blockchain created with ID: ${result.blockchainID}`);
      addLog(`VM ID: ${result.vmID}`);
      
      setDeployStatus('success');
      addLog('Deployment successful! Your custom VM is now live on Fuji Testnet');

      // Start polling for status
      pollVMStatus(result.vmID);
    } catch (error) {
      setDeployStatus('error');
      addLog('Error during deployment: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
  };

  const pollVMStatus = async (vmID: string) => {
    const interval = setInterval(async () => {
      try {
        const status = await getVMStatus(vmID);
        if (status.status === 'success') {
          addLog('VM is now fully validated and operational');
          clearInterval(interval);
        } else if (status.status === 'failed') {
          addLog('VM validation failed: ' + status.details.error);
          clearInterval(interval);
        }
      } catch (error) {
        console.error('Error polling VM status:', error);
      }
    }, 5000);

    // Cleanup
    return () => clearInterval(interval);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-gray-800 rounded-lg p-6 mb-8">
        <h2 className="text-2xl font-bold mb-4">Deploy to Avalanche</h2>
        <p className="text-gray-300 mb-6">
          Deploy your custom Virtual Machine to the Avalanche Fuji Testnet.
          Make sure you have sufficient AVAX test tokens for deployment.
        </p>

        <div className="mb-6">
          <h3 className="text-xl font-semibold mb-4">VM Configuration</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">VM Name</label>
              <input
                type="text"
                value={vmConfig.name}
                onChange={(e) => setVmConfig(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500"
                placeholder="Enter VM name"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">VM ID</label>
              <input
                type="text"
                value={vmConfig.vmID}
                onChange={(e) => setVmConfig(prev => ({ ...prev, vmID: e.target.value }))}
                className="w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500"
                placeholder="Enter VM ID"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Genesis Data</label>
              <textarea
                value={vmConfig.genesisData}
                onChange={(e) => setVmConfig(prev => ({ ...prev, genesisData: e.target.value }))}
                className="w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500 h-32 font-mono"
                placeholder="Enter genesis data in JSON format"
              />
            </div>
          </div>
        </div>

        <button
          onClick={handleDeploy}
          disabled={deployStatus === 'deploying'}
          className={`w-full py-3 rounded-lg flex items-center justify-center ${
            deployStatus === 'deploying'
              ? 'bg-gray-600 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {deployStatus === 'deploying' ? (
            <>
              <RefreshCw className="animate-spin mr-2" />
              Deploying to Avalanche...
            </>
          ) : (
            <>
              <Upload className="mr-2" />
              Deploy VM
            </>
          )}
        </button>
      </div>

      {logs.length > 0 && (
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            {deployStatus === 'success' && <CheckCircle className="text-green-400 mr-2" />}
            {deployStatus === 'error' && <AlertCircle className="text-red-400 mr-2" />}
            Deployment Logs
          </h3>
          <div className="bg-gray-900 rounded-lg p-4">
            {logs.map((log, index) => (
              <div key={index} className="mb-2 font-mono text-sm flex items-start">
                <span className="text-gray-500 mr-2">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                <span>{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Deploy;