import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Deploy from './pages/Deploy';
import Interact from './pages/Interact';
import { Cpu } from 'lucide-react';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center mb-8">
            <Cpu className="w-12 h-12 text-blue-400 mr-4" />
            <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              HyperSDK Custom VM
            </h1>
          </div>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/deploy" element={<Deploy />} />
            <Route path="/interact" element={<Interact />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;